# Fact_Check_Mono_Cross
SemEval Task-7

## DataSet Link
- https://iiitaphyd-my.sharepoint.com/:f:/g/personal/karan_nijhawan_students_iiit_ac_in/Ege7PYgqB6hHj43rCzC0998BmbdV00LQvuGaw3NRiGwWvQ?e=u6CdW3